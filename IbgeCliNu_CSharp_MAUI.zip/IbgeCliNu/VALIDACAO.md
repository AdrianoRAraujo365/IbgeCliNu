# Validação — 17/11/2026

## Executado no sandbox

- Parsing sintático C# com Tree-sitter: 24 arquivos, sem erros sintáticos na verificação final.
- Parsing XML: 20 arquivos XAML/XML/plist/manifest/SVG/csproj, sem erros de estrutura XML.
- Verificação dos oito handlers de eventos declarados no XAML: todos encontrados nos respectivos code-behind.
- IBGE estados: HTTP 200, 27 registros.
- IBGE municípios SP: HTTP 200, 645 registros.
- ViaCEP `01001000`: HTTP 200.
- Geocodificação São Paulo, Brasil: HTTP 200; retornou correspondências no estado São Paulo. O serviço filtra país/estado/nome, usando a primeira correspondência exata.
- Open-Meteo, coordenadas próximas ao centro de São Paulo: HTTP 200, cinco datas de previsão.
- Documentação USDA: HTTP 200.
- Pacote NuGet Microsoft.Maui.Controls 10.0.0: HTTP 200 no endpoint oficial do pacote.
- Arquivo ZIP: integridade e lista de arquivos conferidas antes da entrega.

Resultados HTTP e contagens estão em `http-tests.json` e `static-tests.json`. Esses testes HTTP foram feitos diretamente nos endpoints, **não pelo aplicativo C# em execução**.

## Não executado

O SDK `dotnet` não está instalado neste ambiente Linux. Não houve restore/build MAUI, compilação XAML, geração de executáveis, execução em emulador/aparelho ou teste visual. Parsing sintático **não** garante resolução de tipos, APIs do framework, recursos de plataforma ou assinatura.

Não houve consulta autenticada USDA: a chave deve ser configurada pelo usuário no dispositivo. Não houve validação real de SecureStorage, Launcher ou WebView nas plataformas de destino. Nenhuma captura de um app em execução é fornecida.

## Checklist no Windows/macOS

1. Instalar SDK .NET 10 e ferramentas/workload MAUI compatíveis. Abrir o `.csproj`, restaurar e compilar o framework de destino.
2. Verificar todos os recursos XAML, ícones convertidos de SVG para PNG e inicialização de cada aba por DI.
3. Testar janelas de 360/390, 768 e 1200 unidades de largura; validar rolagem, teclado virtual, orientação e layout de uma/duas colunas. Testar ampliação de fonte.
4. IBGE: listar estados, selecionar SP e São Paulo, consultar clima; alternar estados rapidamente durante carregamento; conferir município selecionado e ausência de resultado antigo.
5. Testar uma cidade homônima de outro estado e uma cidade sem resolução GeoNames. Conferir falha explícita em vez de fallback incorreto.
6. Conferir temperatura/umidade, média diária e cinco datas; confirmar legenda e aviso de mapa sintético. Desabilitar internet/CDNs e verificar mensagens e limites da WebView.
7. ViaCEP: `01001-000`, `01001000`, CEP com menos de oito dígitos e CEP inexistente. Após resultado válido, consultar um inválido e verificar limpeza dos campos.
8. Nutrição: sem chave, chave inválida, chave válida, termo inexistente, `apple`, `banana`. Conferir origem Foundation/SR Legacy, base 100 g e unidades.
9. Salvar a chave, fechar/reabrir o app e verificar persistência sem exibir o segredo; remover chave e verificar pedido de configuração. Em iOS, conferir assinatura/entitlement do Keychain.
10. Simular timeout, limite HTTP 429 e perda de conexão. Confirmar bloqueio de chamadas repetidas e reativação dos controles.

Somente após esses passos a compilação e o comportamento nas plataformas podem ser considerados validados.