# Arquitetura e fontes

```text
App / MauiProgram → AppShell (três ShellContent)
  → Views (XAML + code-behind e AdaptiveLayout nativo)
  → Services (IbgeService, ClimaService, ViaCepService, FoodNutritionService)
  → ApiClient / HttpClient (HTTPS, timeout 25 segundos)
  → APIs externas → JSON → Models → controles / WebView
```

## Endpoints
- `https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome`
- `https://servicodados.ibge.gov.br/api/v1/localidades/estados/{UF}/municipios?orderBy=nome`
- `https://viacep.com.br/ws/{CEP}/json/`
- `https://geocoding-api.open-meteo.com/v1/search` com `name`, `countryCode=BR`, `count=100`, `language=pt`.
- `https://api.open-meteo.com/v1/forecast` com latitude/longitude, temperatura/umidade atuais, média/máxima/mínima diárias, `forecast_days=5`, `timezone=auto`.
- `https://api.nal.usda.gov/fdc/v1/foods/search` com termo, tipos Foundation/SR Legacy e limite dez. Autenticação: header `X-Api-Key`.

Sem BaseAddress mutável compartilhado: os serviços usam URLs absolutas. Carregamento de municípios cancelável evita exibir municípios de um estado anteriormente selecionado. Botões bloqueados durante consultas; resultados antigos ocultados/limpos antes de uma nova chamada. Timeout, conexão, JSON inválido, limites e acesso recusado recebem mensagens sem expor URLs/chaves.

JSON contracts adaptados dos TXT originais. Navegação baseada em Shell como no DOCX, com DataTemplates que obtêm páginas injetadas. Arquitetura didática em code-behind; não é uma implementação MVVM. Os helpers de formulário são pontos de extensão; carregamento IBGE é assíncrono.

Armazenamento persistente apenas da chave USDA em SecureStorage. Android desativa backup para evitar restaurar uma chave criptografada em outro dispositivo. Não há permissões de localização: coordenadas são obtidas pela busca de cidade. Texto de popup do mapa é serializado com System.Text.Json e atribuído com textContent, evitando HTML vindo do nome consultado.

## Documentação oficial
- https://learn.microsoft.com/dotnet/maui/what-is-maui?view=net-maui-10.0
- https://learn.microsoft.com/dotnet/maui/supported-platforms?view=net-maui-10.0
- https://learn.microsoft.com/dotnet/maui/platform-integration/storage/secure-storage?view=net-maui-10.0
- https://servicodados.ibge.gov.br/api/docs/localidades
- https://viacep.com.br/
- https://open-meteo.com/en/docs
- https://open-meteo.com/en/docs/geocoding-api
- https://fdc.nal.usda.gov/api-guide
- https://www.openstreetmap.org/copyright

Os anexos privados originais não foram incluídos no ZIP. Apenas código adaptado e documentação da entrega.
