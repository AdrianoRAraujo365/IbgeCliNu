using UIKit;
namespace IbgeCliNu;
public class Program { static void Main(string[] args) => UIApplication.Main(args,null,typeof(AppDelegate)); }
