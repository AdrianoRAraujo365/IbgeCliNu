using Foundation;
namespace IbgeCliNu;
[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{ protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp(); }
