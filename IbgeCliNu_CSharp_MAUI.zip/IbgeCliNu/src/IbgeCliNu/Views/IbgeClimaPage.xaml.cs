using IbgeCliNu.Models;
using IbgeCliNu.Services;
using System.Globalization;
using System.Text.Json;

namespace IbgeCliNu.Views
{
    public partial class IbgeClimaPage : ContentPage
    {
        private readonly IbgeService _ibgeService;
        private readonly ClimaService _climaService;

        private CancellationTokenSource? _municipiosCts;
        private bool _carregando;
        private bool _aplicandoForm;
        public IbgeClimaPage(IbgeService ibgeService, ClimaService climaService)
        {
            InitializeComponent();
            _ibgeService = ibgeService;
            _climaService = climaService;
            if (Content is ScrollView scroll && scroll.Content is VerticalStackLayout root)
            {
                root.Children.Remove(FormularioBorder);
                root.Children.Remove(ResultadoLayout);
                root.Children.Add(new AdaptiveLayout(FormularioBorder, ResultadoLayout));
            }
            CidadePicker.SelectedIndexChanged += (_, _) => { ResultadoLayout.IsVisible = false; AtualLabel.Text = ""; };
        }

        protected override void OnAppearing() { base.OnAppearing(); if (EstadoPicker.ItemsSource == null && !_carregando) CarregarEstadosAsync(); }
        private void RecarregarButton_Clicked(object? sender, EventArgs e) => CarregarEstadosAsync();
        private async void CarregarEstadosAsync()
        {
            if (_carregando) return;
            _carregando = true; RecarregarButton.IsEnabled = false;
            try
            {
                LoadingIndicator.IsVisible = true;
                LoadingIndicator.IsRunning = true;
                EstadoPicker.ItemsSource = await _ibgeService.ListarEstadosAsync();
            }
            catch (Exception ex)
            {
                await DisplayAlertAsync("Erro IBGE", $"Falha ao carregar estados: {UiErrors.Message(ex)}", "OK");
            }
            finally
            {
                LoadingIndicator.IsRunning = false;
                LoadingIndicator.IsVisible = false;
                _carregando = false; RecarregarButton.IsEnabled = true;
            }
        }

        private async void EstadoPicker_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (_aplicandoForm) return;
            _municipiosCts?.Cancel(); _municipiosCts?.Dispose();
            var cts = _municipiosCts = new CancellationTokenSource();
            CidadePicker.ItemsSource = null; CidadePicker.IsEnabled = false;
            ResultadoLayout.IsVisible = false; AtualLabel.Text = "";
            if (EstadoPicker.SelectedItem is not EstadoIbge estado) return;
            ConsultarClimaButton.IsEnabled = false;
            try {
                var cidades = await _ibgeService.ListarCidadesPorUfAsync(estado.Sigla, cts.Token);
                if (!cts.IsCancellationRequested) { CidadePicker.ItemsSource = cidades; CidadePicker.IsEnabled = true; }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { if (!cts.IsCancellationRequested) await DisplayAlertAsync("Erro IBGE", UiErrors.Message(ex), "OK"); }
            finally { if (!cts.IsCancellationRequested) ConsultarClimaButton.IsEnabled = true; }
        }

        private async void ConsultarClimaButton_Clicked(object? sender, EventArgs e)
        {
            if (EstadoPicker.SelectedItem is not EstadoIbge estado ||
                CidadePicker.SelectedItem is not MunicipioIbge cidade)
            {
                await DisplayAlertAsync("Atenção", "Selecione um estado e uma cidade.", "OK");
                return;
            }

            try
            {
                ResultadoLayout.IsVisible = false; AtualLabel.Text = "";
                EstadoPicker.IsEnabled = CidadePicker.IsEnabled = RecarregarButton.IsEnabled = false;
                ConsultarClimaButton.IsEnabled = false;
                LoadingIndicator.IsVisible = true;
                LoadingIndicator.IsRunning = true;

                var clima = await _climaService.ConsultarPorCidadeAsync(cidade.Nome, estado.Nome);
                if (clima == null)
                {
                    await DisplayAlertAsync("Aviso", "Não foi possível obter os dados climáticos para esta cidade.", "OK");
                    return;
                }

                string? logradouro = LogradouroEntry.Text?.Trim();
                EnderecoLabel.Text = string.IsNullOrWhiteSpace(logradouro)
                    ? $"{cidade.Nome} - {estado.Sigla}"
                    : $"{logradouro}, {cidade.Nome} - {estado.Sigla}";

                AtualLabel.Text = $"Agora: {clima.TemperaturaAtual:F1} °C · Umidade: {clima.Umidade}% · Open-Meteo";
                MediaLabel.Text = FormatarTemperatura(clima.TemperaturaMedia);
                MaximaLabel.Text = FormatarTemperatura(clima.TemperaturaMaxima);
                MinimaLabel.Text = FormatarTemperatura(clima.TemperaturaMinima);

                RenderizarMapaCalorEGrafico(clima, cidade.Nome);
                ResultadoLayout.IsVisible = true;
            }
            catch (Exception ex)
            {
                ResultadoLayout.IsVisible = false;
                await DisplayAlertAsync("Erro", $"Erro ao consultar clima: {UiErrors.Message(ex)}", "OK");
            }
            finally
            {
                LoadingIndicator.IsRunning = false;
                LoadingIndicator.IsVisible = false;
                ConsultarClimaButton.IsEnabled = EstadoPicker.IsEnabled = CidadePicker.IsEnabled = RecarregarButton.IsEnabled = true;
            }
        }

        private void RenderizarMapaCalorEGrafico(ResumoClima clima, string nomeCidade)
        {
            string lat = clima.Latitude.ToString(CultureInfo.InvariantCulture);
            string lon = clima.Longitude.ToString(CultureInfo.InvariantCulture);

            // Intensidade térmica normalizada entre 0.3 e 1.0 com base na temperatura máxima
            double intensidadeBase = Math.Clamp((clima.TemperaturaMaxima - 10.0) / 30.0, 0.3, 1.0);
            string intStr = intensidadeBase.ToString("F2", CultureInfo.InvariantCulture);
            string intMid = (intensidadeBase * 0.75).ToString("F2", CultureInfo.InvariantCulture);

            string diasJson = JsonSerializer.Serialize(clima.Daily.Time);
            string maxJson = JsonSerializer.Serialize(clima.Daily.TemperatureMax);
            string minJson = JsonSerializer.Serialize(clima.Daily.TemperatureMin);

            string popupJson = JsonSerializer.Serialize($"{nomeCidade} · Máx: {clima.TemperaturaMaxima:F1} °C | Mín: {clima.TemperaturaMinima:F1} °C · SIMULAÇÃO");
            string html = $@"<!DOCTYPE html>
            <html lang='pt-br'>
            <head>
                <meta charset='utf-8' />
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css' />
                <script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>
                <script src='https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js'></script>
                <script src='https://cdn.jsdelivr.net/npm/chart.js@3.7.0/dist/chart.min.js'></script>
                <style>
                    body {{ font-family: sans-serif; margin: 0; padding: 6px; display: flex; flex-direction: column; gap: 8px; height: 100vh; box-sizing: border-box; }}
                    #heatmap {{ height: 54%; width: 100%; border-radius: 8px; }}
                    .chart-box {{ height: 42%; width: 100%; }}
                </style>
            </head>
            <body>
                <div style='font:12px sans-serif;color:#68736d'>Camada térmica SIMULADA · não é medição por bairro. Mapa-base: OpenStreetMap.</div>
                <div id='heatmap'></div>
                <div class='chart-box'><canvas id='tempChart'></canvas></div>
                <script>
                    var lat = {lat};
                    var lon = {lon};
                    var map = L.map('heatmap').setView([lat, lon], 11);

                    L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
                        maxZoom: 18,
                        attribution: '&copy; OpenStreetMap'
                    }}).addTo(map);

                    // Pontos distribuídos na malha urbana para renderização do Mapa de Calor
                    var pontosCalor = [
                        [lat, lon, {intStr}],
                        [lat + 0.015, lon + 0.015, {intStr}],
                        [lat - 0.015, lon - 0.012, {intMid}],
                        [lat + 0.012, lon - 0.018, {intMid}],
                        [lat - 0.018, lon + 0.014, {intStr}],
                        [lat + 0.006, lon + 0.008, {intStr}],
                        [lat - 0.007, lon - 0.006, {intMid}]
                    ];

                    L.heatLayer(pontosCalor, {{
                        radius: 38,
                        blur: 24,
                        maxZoom: 14,
                        gradient: {{ 0.2: '#3b82f6', 0.5: '#22c55e', 0.75: '#f59e0b', 1.0: '#ef4444' }}
                    }}).addTo(map);

                    var popup = document.createElement('span'); popup.textContent = {popupJson};
                    L.marker([lat, lon]).addTo(map).bindPopup(popup)
                        .openPopup();

                    var ctx = document.getElementById('tempChart').getContext('2d');
                    new Chart(ctx, {{
                        type: 'line',
                        data: {{
                            labels: {diasJson},
                            datasets: [
                                {{
                                    label: 'Máxima (°C)',
                                    data: {maxJson},
                                    borderColor: '#ef4444',
                                    backgroundColor: 'rgba(239, 68, 68, 0.15)',
                                    fill: true,
                                    tension: 0.3
                                }},
                                {{
                                    label: 'Mínima (°C)',
                                    data: {minJson},
                                    borderColor: '#3b82f6',
                                    backgroundColor: 'rgba(59, 130, 246, 0.15)',
                                    fill: true,
                                    tension: 0.3
                                }}
                            ]
                        }},
                        options: {{ responsive: true, maintainAspectRatio: false }}
                    }});
                </script>
            </body>
            </html>";

            MapaCalorWebView.Source = new HtmlWebViewSource { Html = html };
        }

        public bool ValidaForm(out string erro) { erro = EstadoPicker.SelectedItem is EstadoIbge && CidadePicker.SelectedItem is MunicipioIbge ? "" : "Selecione estado e cidade."; return erro.Length == 0; }
        public (string Logradouro, EstadoIbge? Estado, MunicipioIbge? Cidade) GetForm() => (LogradouroEntry.Text ?? "", EstadoPicker.SelectedItem as EstadoIbge, CidadePicker.SelectedItem as MunicipioIbge);
        public async Task SetFormAsync(string uf, int cidadeId, string logradouro = "") {
            _municipiosCts?.Cancel(); _aplicandoForm = true;
            try {
                var estados = await _ibgeService.ListarEstadosAsync(); EstadoPicker.ItemsSource = estados;
                var estado = estados.FirstOrDefault(e => e.Sigla == uf); EstadoPicker.SelectedItem = estado;
                CidadePicker.ItemsSource = null; CidadePicker.IsEnabled = false;
                if (estado != null) {
                    var cidades = await _ibgeService.ListarCidadesPorUfAsync(uf);
                    CidadePicker.ItemsSource = cidades;
                    CidadePicker.SelectedItem = cidades.FirstOrDefault(c => c.Id == cidadeId);
                    CidadePicker.IsEnabled = true;
                }
                LogradouroEntry.Text = logradouro;
                ResultadoLayout.IsVisible = false; AtualLabel.Text = "";
            }
            finally { _aplicandoForm = false; ConsultarClimaButton.IsEnabled = true; }
        }
        public void ClearForm() { LogradouroEntry.Text = ""; EstadoPicker.SelectedIndex = -1; CidadePicker.ItemsSource = null; ResultadoLayout.IsVisible = false; AtualLabel.Text = ""; }
        private static string FormatarTemperatura(double valor) =>
            $"{valor.ToString("F1", CultureInfo.GetCultureInfo("pt-BR"))} °C";
    }
}
