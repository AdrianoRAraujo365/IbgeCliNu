namespace IbgeCliNu.Views;

/// <summary>Move native views to two columns on wide windows, stack on phones.</summary>
internal sealed class AdaptiveLayout : Grid
{
    private readonly View _left, _right;
    private bool? _wide;
    public AdaptiveLayout(View left, View right)
    {
        _left = left; _right = right;
        ColumnSpacing = 24; RowSpacing = 24;
        Children.Add(left); Children.Add(right);
        SizeChanged += (_, _) => Adapt();
        Adapt();
    }
    private void Adapt()
    {
        var wide = Width >= 850;
        if (_wide == wide) return;
        _wide = wide;
        ColumnDefinitions.Clear(); RowDefinitions.Clear();
        ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
        if (wide) ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.4, GridUnitType.Star) });
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        if (!wide) RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        Grid.SetColumn(_left, 0); Grid.SetRow(_left, 0);
        Grid.SetColumn(_right, wide ? 1 : 0); Grid.SetRow(_right, wide ? 0 : 1);
    }
}