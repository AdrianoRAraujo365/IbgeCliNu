using IbgeCliNu.Services;

namespace IbgeCliNu.Views
{
    public partial class ViaCepPage : ContentPage
    {
        private readonly ViaCepService _viaCepService;

        public ViaCepPage(ViaCepService viaCepService)
        {
            InitializeComponent();
            _viaCepService = viaCepService;
            if (Content is ScrollView scroll && scroll.Content is VerticalStackLayout root)
            {
                var form = root.Children.OfType<Grid>().FirstOrDefault();
                var result = root.Children.OfType<Border>().FirstOrDefault();
                if (form != null && result != null) {
                    root.Children.Remove(form); root.Children.Remove(result);
                    root.Children.Add(new AdaptiveLayout(form, result));
                }
            }
        }

        private async void BuscarCepButton_Clicked(object? sender, EventArgs e)
        {
            string cep = CepEntry.Text?.Trim() ?? string.Empty;
            if (string.IsNullOrWhiteSpace(cep))
            {
                await DisplayAlertAsync("Atenção", "Digite um CEP com 8 dígitos.", "OK");
                return;
            }

            try
            {
                LimparCampos();
                BuscarCepButton.IsEnabled = false;
                LoadingIndicator.IsVisible = true;
                LoadingIndicator.IsRunning = true;

                var endereco = await _viaCepService.ObterEnderecoPorCepAsync(cep);
                if (endereco == null)
                {
                    LimparCampos();
                    await DisplayAlertAsync("Não encontrado", "CEP inválido ou inexistente na base ViaCEP.", "OK");
                    return;
                }

                LogradouroEntry.Text = string.IsNullOrWhiteSpace(endereco.Logradouro) ? "Não informado pelo ViaCEP" : endereco.Logradouro;
                BairroEntry.Text = endereco.Bairro;
                CidadeEntry.Text = endereco.Localidade;
                EstadoEntry.Text = string.IsNullOrWhiteSpace(endereco.Estado)
                    ? endereco.Uf
                    : $"{endereco.Estado} ({endereco.Uf})";
                DddEntry.Text = endereco.Ddd;
                IbgeEntry.Text = endereco.Ibge;
            }
            catch (Exception ex)
            {
                await DisplayAlertAsync("Erro", $"Falha ao consultar ViaCEP: {UiErrors.Message(ex)}", "OK");
            }
            finally
            {
                LoadingIndicator.IsRunning = false;
                LoadingIndicator.IsVisible = false;
                BuscarCepButton.IsEnabled = true;
            }
        }

        public bool ValidaForm(out string erro) { erro = new string((CepEntry.Text ?? "").Where(char.IsDigit).ToArray()).Length == 8 ? "" : "Informe oito dígitos."; return erro.Length == 0; }
        public string GetForm() => CepEntry.Text ?? "";
        public void SetForm(string cep) => CepEntry.Text = cep;
        public void ClearForm() { CepEntry.Text = ""; LimparCampos(); }
        private void LimparCampos()
        {
            LogradouroEntry.Text = string.Empty;
            BairroEntry.Text = string.Empty;
            CidadeEntry.Text = string.Empty;
            EstadoEntry.Text = string.Empty;
            DddEntry.Text = string.Empty;
            IbgeEntry.Text = string.Empty;
        }
    }
}
