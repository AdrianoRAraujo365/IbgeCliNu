using IbgeCliNu.Services;

namespace IbgeCliNu.Views
{
    public partial class NutricaoPage : ContentPage
    {
        private readonly FoodNutritionService _foodService;

        public NutricaoPage(FoodNutritionService foodService)
        {
            InitializeComponent();
            _foodService = foodService;
        }

        private async void AlimentoSearchBar_SearchButtonPressed(object? sender, EventArgs e)
        {
            string termo = AlimentoSearchBar.Text?.Trim() ?? string.Empty;
            if (string.IsNullOrWhiteSpace(termo))
            {
                await DisplayAlertAsync("Atenção", "Digite o nome de um alimento.", "OK");
                return;
            }

            if (LoadingIndicator.IsRunning) return;
            AlimentoSearchBar.IsEnabled = false;
            try
            {
                LoadingIndicator.IsVisible = true;
                LoadingIndicator.IsRunning = true;
                AlimentosCollectionView.ItemsSource = null;

                var resultados = await _foodService.PesquisarAlimentoAsync(termo, limite: 10);
                AlimentosCollectionView.ItemsSource = resultados;

                if (resultados.Count == 0)
                {
                    await DisplayAlertAsync("Sem resultados", "Nenhum alimento encontrado na base USDA.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlertAsync("Erro USDA API", $"Não foi possível buscar nutrientes: {UiErrors.Message(ex)}", "OK");
            }
            finally
            {
                AlimentoSearchBar.IsEnabled = true;
                LoadingIndicator.IsRunning = false;
                LoadingIndicator.IsVisible = false;
            }
        }

        protected override async void OnAppearing() {
            base.OnAppearing();
            try { ChaveStatusLabel.Text = string.IsNullOrWhiteSpace(await _foodService.ObterChaveAsync()) ? "Chave não configurada." : "Chave configurada neste dispositivo."; }
            catch { ChaveStatusLabel.Text = "Armazenamento seguro indisponível. Verifique sua plataforma."; }
        }
        private async void SalvarChave_Clicked(object? sender, EventArgs e) {
            var key = ChaveEntry.Text?.Trim();
            if (string.IsNullOrWhiteSpace(key) || key.Any(char.IsWhiteSpace)) { ChaveStatusLabel.Text = "Informe a chave sem espaços."; return; }
            try { await _foodService.SalvarChaveAsync(key); ChaveEntry.Text = ""; ChaveStatusLabel.Text = "Chave salva; validade será verificada na pesquisa."; }
            catch { ChaveStatusLabel.Text = "Não foi possível salvar a chave no armazenamento seguro."; }
        }
        private void RemoverChave_Clicked(object? sender, EventArgs e) {
            try { _foodService.RemoverChave(); ChaveEntry.Text = ""; ChaveStatusLabel.Text = "Chave removida."; }
            catch { ChaveStatusLabel.Text = "Não foi possível remover a chave."; }
        }
        private async void ObterChave_Clicked(object? sender, EventArgs e) {
            try { await Launcher.Default.OpenAsync("https://fdc.nal.usda.gov/api-key-signup"); }
            catch { ChaveStatusLabel.Text = "Acesse fdc.nal.usda.gov/api-key-signup no navegador."; }
        }
        public bool ValidaForm(out string erro) { erro = string.IsNullOrWhiteSpace(AlimentoSearchBar.Text) ? "Digite um alimento." : ""; return erro.Length == 0; }
        public string GetForm() => AlimentoSearchBar.Text ?? "";
        public void SetForm(string termo) => AlimentoSearchBar.Text = termo;
        public void ClearForm() { AlimentoSearchBar.Text = ""; AlimentosCollectionView.ItemsSource = null; }
    }
}
