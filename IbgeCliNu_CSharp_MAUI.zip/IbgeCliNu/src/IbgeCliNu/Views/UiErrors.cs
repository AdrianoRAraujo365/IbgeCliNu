namespace IbgeCliNu.Views;
internal static class UiErrors
{
 public static string Message(Exception ex) => ex is ArgumentException or InvalidOperationException ? ex.Message : "Não foi possível concluir a operação. Verifique a configuração e tente novamente.";
}
