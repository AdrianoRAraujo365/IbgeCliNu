using IbgeCliNu.Views;
namespace IbgeCliNu;
public partial class AppShell : Shell
{
 public AppShell(IbgeClimaPage clima,ViaCepPage cep,NutricaoPage nutri)
 {
  InitializeComponent();
  ClimaTab.ContentTemplate=new DataTemplate(()=>clima);
  CepTab.ContentTemplate=new DataTemplate(()=>cep);
  NutriTab.ContentTemplate=new DataTemplate(()=>nutri);
 }
}
