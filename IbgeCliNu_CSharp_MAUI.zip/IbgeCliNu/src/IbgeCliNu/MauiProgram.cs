using IbgeCliNu.Services;
using IbgeCliNu.Views;
namespace IbgeCliNu;
public static class MauiProgram
{
 public static MauiApp CreateMauiApp()
 {
  var builder=MauiApp.CreateBuilder().UseMauiApp<App>();
  builder.Services.AddSingleton(new HttpClient { Timeout=TimeSpan.FromSeconds(25) });
  builder.Services.AddSingleton<ApiClient>();
  builder.Services.AddSingleton<IbgeService>(); builder.Services.AddSingleton<ClimaService>();
  builder.Services.AddSingleton<ViaCepService>(); builder.Services.AddSingleton<FoodNutritionService>();
  builder.Services.AddSingleton<IbgeClimaPage>(); builder.Services.AddSingleton<ViaCepPage>(); builder.Services.AddSingleton<NutricaoPage>();
  builder.Services.AddSingleton<AppShell>(); return builder.Build();
 }
}
