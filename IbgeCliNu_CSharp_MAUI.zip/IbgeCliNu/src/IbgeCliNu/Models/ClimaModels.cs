using System.Text.Json.Serialization;

namespace IbgeCliNu.Models
{
    public class GeocodingResponse
    {
        [JsonPropertyName("results")]
        public List<GeoLocation>? Results { get; set; }
    }

    public class GeoLocation
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("latitude")]
        public double Latitude { get; set; }

        [JsonPropertyName("longitude")]
        public double Longitude { get; set; }

        [JsonPropertyName("country")]
        public string? Country { get; set; }

        [JsonPropertyName("admin1")]
        public string? Admin1 { get; set; }
        [JsonPropertyName("country_code")] public string? CountryCode { get; set; }
    }

    public class WeatherResponse
    {
        [JsonPropertyName("current")]
        public CurrentWeather? Current { get; set; }

        [JsonPropertyName("daily")]
        public DailyWeather? Daily { get; set; }
    }

    public class CurrentWeather
    {
        [JsonPropertyName("temperature_2m")]
        public double Temperature { get; set; }

        [JsonPropertyName("relative_humidity_2m")]
        public int Humidity { get; set; }
    }

    public class DailyWeather
    {
        [JsonPropertyName("time")]
        public List<string>? Time { get; set; }

        [JsonPropertyName("temperature_2m_max")]
        public List<double>? TemperatureMax { get; set; }

        [JsonPropertyName("temperature_2m_min")]
        public List<double>? TemperatureMin { get; set; }

        [JsonPropertyName("temperature_2m_mean")]
        public List<double>? TemperatureMean { get; set; }
    }

    public class ResumoClima
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double TemperaturaAtual { get; set; }
        public int Umidade { get; set; }
        public double TemperaturaMedia { get; set; }
        public double TemperaturaMaxima { get; set; }
        public double TemperaturaMinima { get; set; }
        public DailyWeather Daily { get; set; } = new();
    }
}
