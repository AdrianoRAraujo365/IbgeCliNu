using System.Text.Json.Serialization;

namespace IbgeCliNu.Models
{
    public class EstadoIbge
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("sigla")]
        public string Sigla { get; set; } = string.Empty;

        [JsonPropertyName("nome")]
        public string Nome { get; set; } = string.Empty;

        public override string ToString() => $"{Nome} ({Sigla})";
    }

    public class MunicipioIbge
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("nome")]
        public string Nome { get; set; } = string.Empty;

        public override string ToString() => Nome;
    }
}
