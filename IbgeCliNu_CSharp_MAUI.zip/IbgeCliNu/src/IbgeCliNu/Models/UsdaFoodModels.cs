using System.Text.Json.Serialization;

namespace IbgeCliNu.Models
{
    public class FoodSearchResponse
    {
        [JsonPropertyName("totalHits")]
        public int TotalHits { get; set; }

        [JsonPropertyName("foods")]
        public List<FoodItem> Foods { get; set; } = new();
    }

    public class FoodItem
    {
        [JsonPropertyName("fdcId")]
        public int FdcId { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; } = string.Empty;

        [JsonPropertyName("foodCategory")]
        public string? FoodCategory { get; set; }

        [JsonPropertyName("foodNutrients")]
        public List<NutrientDetail> FoodNutrients { get; set; } = new();
    }

    public class NutrientDetail
    {
        [JsonPropertyName("nutrientName")]
        public string NutrientName { get; set; } = string.Empty;
        [JsonIgnore]
        public string DisplayName => NutrientName switch {
            "Energy" => "Energia", "Protein" => "Proteínas", "Total lipid (fat)" => "Gorduras totais",
            "Carbohydrate, by difference" => "Carboidratos", "Fiber, total dietary" => "Fibras",
            "Sugars, total including NLEA" => "Açúcares totais", _ => NutrientName
        };

        [JsonPropertyName("value")]
        public double Value { get; set; }

        [JsonPropertyName("unitName")]
        public string UnitName { get; set; } = string.Empty;
    }
}
