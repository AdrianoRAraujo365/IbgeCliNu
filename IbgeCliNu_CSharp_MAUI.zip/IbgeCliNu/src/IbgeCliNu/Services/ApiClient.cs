using System.Net;
using System.Net.Http.Json;
namespace IbgeCliNu.Services;
public sealed class ApiClient(HttpClient client)
{
 public async Task<T> GetAsync<T>(string url,CancellationToken ct=default,string? key=null)
 {
  try {
   using var req=new HttpRequestMessage(HttpMethod.Get,url);
   if(key is not null) req.Headers.Add("X-Api-Key",key);
   using var res=await client.SendAsync(req,ct);
   if(res.StatusCode==HttpStatusCode.TooManyRequests) throw new InvalidOperationException("Limite de consultas atingido. Aguarde e tente novamente.");
   if(res.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized) throw new InvalidOperationException("Acesso recusado. Na USDA, verifique a chave configurada.");
   if(!res.IsSuccessStatusCode) throw new InvalidOperationException($"Serviço indisponível (HTTP {(int)res.StatusCode}).");
   return await res.Content.ReadFromJsonAsync<T>(cancellationToken:ct) ?? throw new InvalidOperationException("Resposta vazia do serviço.");
  }
  catch(OperationCanceledException) when(!ct.IsCancellationRequested) { throw new InvalidOperationException("A consulta excedeu o tempo limite. Tente novamente."); }
  catch(HttpRequestException) { throw new InvalidOperationException("Não foi possível conectar ao serviço. Verifique a internet."); }
  catch(System.Text.Json.JsonException) { throw new InvalidOperationException("Resposta do serviço em formato inesperado."); }
 }
}
