using IbgeCliNu.Models;
namespace IbgeCliNu.Services;
public class ViaCepService(ApiClient api)
{
 public async Task<ViaCepResponse?> ObterEnderecoPorCepAsync(string cep)
 {
  var clean=new string(cep.Where(char.IsDigit).ToArray());
  if(clean.Length!=8) return null;
  var result=await api.GetAsync<ViaCepResponse>($"https://viacep.com.br/ws/{clean}/json/");
  return result.Erro ? null : result;
 }
}
