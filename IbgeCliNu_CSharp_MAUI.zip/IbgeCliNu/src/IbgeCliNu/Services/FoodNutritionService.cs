using IbgeCliNu.Models;
namespace IbgeCliNu.Services;
public class FoodNutritionService(ApiClient api)
{
 private const string KeyName="usda-fdc-key";
 public Task<string?> ObterChaveAsync() => SecureStorage.Default.GetAsync(KeyName);
 public Task SalvarChaveAsync(string chave) => SecureStorage.Default.SetAsync(KeyName,chave.Trim());
 public void RemoverChave() => SecureStorage.Default.Remove(KeyName);
 public async Task<List<FoodItem>> PesquisarAlimentoAsync(string termo,int limite=10)
 {
  var key=await ObterChaveAsync();
  if(string.IsNullOrWhiteSpace(key)) throw new InvalidOperationException("Configure sua chave USDA nesta aba antes de pesquisar.");
  var result=await api.GetAsync<FoodSearchResponse>($"https://api.nal.usda.gov/fdc/v1/foods/search?query={Uri.EscapeDataString(termo)}&pageSize={Math.Clamp(limite,1,10)}&dataType=Foundation&dataType=SR%20Legacy",key:key);
  string[] names={"Energy","Protein","Total lipid (fat)","Carbohydrate, by difference","Fiber, total dietary","Sugars, total including NLEA"};
  foreach(var food in result.Foods) food.FoodNutrients=food.FoodNutrients.Where(n=>names.Contains(n.NutrientName) && (n.NutrientName!="Energy" || n.UnitName.Equals("KCAL",StringComparison.OrdinalIgnoreCase))).ToList();
  return result.Foods;
 }
}
