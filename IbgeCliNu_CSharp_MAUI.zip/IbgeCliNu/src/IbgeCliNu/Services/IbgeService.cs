using IbgeCliNu.Models;
namespace IbgeCliNu.Services;
public class IbgeService(ApiClient api)
{
 private const string Base="https://servicodados.ibge.gov.br/api/v1/localidades/";
 private List<EstadoIbge>? _estados;
 public async Task<List<EstadoIbge>> ListarEstadosAsync() => _estados ??= await api.GetAsync<List<EstadoIbge>>(Base+"estados?orderBy=nome");
 public Task<List<MunicipioIbge>> ListarCidadesPorUfAsync(string uf,CancellationToken ct=default)
  => api.GetAsync<List<MunicipioIbge>>(Base+$"estados/{Uri.EscapeDataString(uf)}/municipios?orderBy=nome",ct);
}
