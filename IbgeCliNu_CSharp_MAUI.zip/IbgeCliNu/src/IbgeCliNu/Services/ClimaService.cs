using IbgeCliNu.Models;
using System.Globalization;
using System.Text;
namespace IbgeCliNu.Services;
public class ClimaService(ApiClient api)
{
 private static string Normalize(string text) => new string(text.Normalize(NormalizationForm.FormD)
  .Where(c=>CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark).ToArray()).ToLowerInvariant();
 public async Task<ResumoClima?> ConsultarPorCidadeAsync(string cidade,string estadoNome)
 {
  var geo=await api.GetAsync<GeocodingResponse>($"https://geocoding-api.open-meteo.com/v1/search?name={Uri.EscapeDataString(cidade)}&count=100&language=pt&countryCode=BR&format=json");
  var local=geo.Results?.FirstOrDefault(l=>l.CountryCode=="BR" && Normalize(l.Admin1 ?? "")==Normalize(estadoNome) && Normalize(l.Name ?? "")==Normalize(cidade));
  if(local is null) throw new InvalidOperationException("Cidade não resolvida no estado selecionado. Não foram usadas coordenadas aproximadas.");
  var lat=local.Latitude.ToString(CultureInfo.InvariantCulture); var lon=local.Longitude.ToString(CultureInfo.InvariantCulture);
  var w=await api.GetAsync<WeatherResponse>($"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current=temperature_2m,relative_humidity_2m&daily=temperature_2m_max,temperature_2m_min,temperature_2m_mean&forecast_days=5&timezone=auto");
  if(w.Current is null || w.Daily?.TemperatureMax?.Count is not >0 || w.Daily.TemperatureMin?.Count is not >0 || w.Daily.TemperatureMean?.Count is not >0) throw new InvalidOperationException("Previsão incompleta para esta localidade.");
  return new ResumoClima { Latitude=local.Latitude, Longitude=local.Longitude, TemperaturaAtual=w.Current.Temperature, Umidade=w.Current.Humidity,
   TemperaturaMedia=w.Daily.TemperatureMean[0],TemperaturaMaxima=w.Daily.TemperatureMax[0],TemperaturaMinima=w.Daily.TemperatureMin[0],Daily=w.Daily };
 }
}
