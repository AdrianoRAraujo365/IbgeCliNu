# IbgeCliNu — código C#/.NET MAUI

Aplicativo nativo com **três abas**: IBGE & Clima, ViaCEP e Nutrição. Entrega aprovada para executar fora do Runable, **sem site hospedado**.

## Abrir o projeto
Abra `src/IbgeCliNu/IbgeCliNu.csproj` no Visual Studio com suporte .NET 10 e a carga de trabalho .NET MAUI instalada. O SDK, Android SDK, Windows SDK e/ou Xcode devem ser compatíveis com a versão do workload.

No Windows (PowerShell):
```powershell
cd src/IbgeCliNu
dotnet --info
dotnet workload install maui
dotnet restore
dotnet build -f net10.0-windows10.0.19041.0 -t:Run
```
Ou selecione **Windows Machine** no IDE. Windows usa execução local sem empacotamento (`WindowsPackageType=None`).

Android: abra um emulador ou conecte um aparelho com depuração USB, depois:
```shell
dotnet build -f net10.0-android -t:Run
```
Para apenas compilar, remova `-t:Run`. iOS/Mac Catalyst exigem macOS/Xcode compatível e configuração de assinatura no ambiente de destino. As entitlements de Keychain estão incluídas; ajuste o identificador de aplicativo/grupo de acesso se mudar `ApplicationId`. Não há suporte nativo a navegador ou Linux.

Pacote Microsoft.Maui.Controls fixado em **10.0.0**, cuja existência foi verificada no NuGet. Antes de distribuição em produção, atualize para um patch 10.0.x compatível com seu workload e valide os destinos.

## Configurar a USDA
1. Obtenha sua chave em https://fdc.nal.usda.gov/api-key-signup.
2. Na aba **Nutrição**, insira a chave no campo de senha e toque **Salvar chave**.
3. Pesquise alimentos em inglês: `apple`, `banana`, `rice`, `chicken`.
4. Use **Remover chave** para apagar a configuração local.

A chave fica em **SecureStorage**, não no código ou URL. O campo é apagado depois de salvar. A validade é confirmada na pesquisa. Não há DEMO_KEY, segredo compartilhado, nem fallback com dados inventados. Sem chave, IBGE/ViaCEP/clima funcionam normalmente e a nutrição pede configuração.

Um segredo armazenado no cliente não é inviolável. Para distribuição pública com chave compartilhada, recomenda-se um proxy autenticado com chave somente no servidor; esse servidor não está incluído no escopo.

## O que foi implementado
- **IBGE & Clima:** estados e municípios oficiais; geocodificação Open-Meteo restrita ao Brasil e ao estado selecionado; temperatura atual e umidade; média diária, máxima e mínima; previsão/gráfico de cinco dias e mapa Leaflet/OpenStreetMap.
- **ViaCEP:** CEP com ou sem hífen; logradouro, bairro, localidade/UF, estado, DDD e código IBGE; mensagens para CEP inválido/inexistente. Campos retornados vazios não significam erro da API.
- **Nutrição:** até dez resultados Foundation/SR Legacy, composição por 100 g, FDC ID e nutrientes principais. Nomes dos nutrientes traduzidos; descrições de alimentos mantidas no idioma USDA. Valores ausentes não são convertidos artificialmente em zero. Energia exibida em kcal, não duplicada em kJ.
- **Interface:** tema claro/minimalista inspirado no portfólio fornecido, tipografia de sistema, acentos verde/terracota, menu Shell com abas. IBGE e ViaCEP mudam de uma coluna para duas em janelas a partir de 850 unidades independentes de dispositivo. Nutrição usa lista adaptável e configuração rolável.
- **Código didático:** Models, Services, Views; injeção de dependência; HttpClient compartilhado; métodos `ValidaForm`, `GetForm`, `SetForm`/`SetFormAsync`, `ClearForm`, inspirados no padrão do DOCX.

## Limitações e cuidados
**Mapa de calor simulado:** os pontos térmicos são sintéticos e derivam da máxima da cidade, conforme o exemplo dos TXT. A camada é rotulada como simulação tanto na página quanto no mapa. Não representa temperatura medida por bairro. Coordenadas centrais, mapa-base e previsão são dados reais.

O logradouro opcional só identifica a consulta; não é geocodificado. Se o nome da cidade não for resolvido exatamente no estado, a consulta falha com mensagem em vez de usar uma cidade estrangeira ou aproximação silenciosa. Entre homônimos no mesmo estado, usa a primeira correspondência exata retornada pela base GeoNames.

Mapa e gráfico da WebView dependem de Leaflet, leaflet.heat, Chart.js e tiles externos. Se os CDNs forem bloqueados, essa visualização pode falhar; os indicadores de temperatura retornados continuam na página. Sem cache offline, banco próprio, login, histórico ou CRUD. A consulta de estados possui cache em memória.

Os dados são educativos, não aconselhamento médico/nutricional. APIs externas podem impor limites, mudar contratos ou ficar indisponíveis.

O DOCX foi utilizado como referência de navegação/formulários; não foi adicionada calculadora/IMC. A imagem FLUXO API descreve CRUD de livros em Node/MySQL, fora do escopo aprovado. O retrato e os textos do portfólio não foram reutilizados.

## Validação
**O projeto não foi compilado nem executado em MAUI neste sandbox**, que é Linux e não tem SDK dotnet/workloads MAUI. Foram feitos parsing sintático dos arquivos C#, validação XML/XAML e testes HTTP. Esses testes não substituem compilação, XAML compiler, assinatura, SecureStorage ou inspeção visual em aparelho.

Veja `VALIDACAO.md` para os resultados e o checklist obrigatório no destino. Não são entregues APK/IPA/EXE ou capturas de uma execução MAUI.
